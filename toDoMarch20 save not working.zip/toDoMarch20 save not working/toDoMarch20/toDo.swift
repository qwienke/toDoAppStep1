//
//  toDo.swift
//  toDoMarch20
//
//  Created by Quinn Wienke on 3/20/23.
//

import Foundation

struct ToDo: Equatable {
    let id = UUID()
    var title: String
    var isComplete: Bool
    var dueDate: Date
    var notes: String?
    
    static func ==(lhs: ToDo, rhs: ToDo) -> Bool {
        return lhs.id == rhs.id
    }
    // next we want to supply the table with some base data
    static func loadToDos() -> [ToDo]? {
        return nil
    }
    
    //here we are creting a sample list
    static func loadSampleToDos() -> [ToDo] {
let toDo1 = ToDo(title: "clean bathroom", isComplete: false, dueDate: Date(), notes: "Notes 1")
        let toDo2 = ToDo(title: "eat", isComplete: false, dueDate: Date())
        return [toDo1, toDo2]
    }
}

