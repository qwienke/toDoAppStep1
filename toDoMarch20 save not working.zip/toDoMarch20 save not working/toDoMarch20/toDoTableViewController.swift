//
//  toDoTableViewController.swift
//  toDoMarch20
//
//  Created by Quinn Wienke on 3/20/23.
//

import UIKit

class toDoTableViewController: UITableViewController {

   
    
    //creating an empty array of model cells
    var toDos = [ToDo]()
    override func viewDidLoad() {
        super.viewDidLoad()

        //adding an intelegent button to remove all items at once
        navigationItem.leftBarButtonItem = editButtonItem

       // here we are populating the table with the data that we created in loadToDos and loadSampleToDos
        
        if let savedToDos = ToDo.loadToDos() {
            toDos = savedToDos
        } else {
            toDos = ToDo.loadSampleToDos()
        }
        
       
      
    }
    
    
    @IBAction func unwindToToDoList(segue: UIStoryboardSegue) {
        
    }
    
    // MARK: - Table view data source

   

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return toDos.count
    }
    
   

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Deque cell from given index path

        let cell = tableView.dequeueReusableCell(withIdentifier: "ToDoCellIdentifier", for: indexPath)

    
        
        // Get the model out of the array that corresponds to the cell being displayed.
        let toDo = toDos[indexPath.row]
        
        //update the cells properties and return the cell
        var content = cell.defaultContentConfiguration()
        content.text = toDo.title
        cell.contentConfiguration = content
        
        return cell

       /*
        so this whole part above is grabbing the toDo var created which returns the [toDo] swift file I made. From there I deque the cell and give it an identifier. I then from there I will update the cell properties returning the cells new contents.
        I think this makes it so that when I add new iformation into the tab it adds that to the cell
        */
        
        
    }
    

    //This method allows you o add and edit cells. To allow the delete button to work you need to uncomment the canEditRowAt method and then in the forRowAt method tou need to add your array to remove see NEXT STEP>
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        // NEXT STEP> see below

        if editingStyle == .delete {
            toDos.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
